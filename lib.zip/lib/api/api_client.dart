import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:get/get.dart' as get_x;

import 'package:harismruti/api/api_endpoints.dart';
import 'package:harismruti/helper/log_helper.dart';
import 'package:harismruti/ui/view/splash/splash_screen.dart';
import 'package:harismruti/utils/storage_helper.dart';
import 'package:package_info_plus/package_info_plus.dart';

class ApiClient {
  static Dio? _client;
  static final ApiClient _instance = ApiClient._internal();
  factory ApiClient() => _instance;
  static String currentAppVersion = '';
  ApiClient._internal();

  static List<String> skipAuthEndpoints = [];

  static Future<void> init() async {
    PackageInfo packageInfo = await PackageInfo.fromPlatform();
    currentAppVersion = Platform.isAndroid ? "1" : packageInfo.buildNumber;
    if (_client == null) {
      _client = Dio(
        BaseOptions(
          baseUrl: ApiEndpoints.mainDomain,
          connectTimeout: const Duration(seconds: 15),
          receiveTimeout: const Duration(seconds: 15),
          headers: {'Content-Type': 'application/json'},
        ),
      );

      _client!.interceptors.add(
        InterceptorsWrapper(
          onRequest: (options, handler) async {
            String? token = await _getAccessToken();

            bool shouldSkipAuth = skipAuthEndpoints.any(
              (endpoint) =>
                  options.path.endsWith(endpoint) ||
                  options.uri.path.endsWith(endpoint),
            );
            if (kDebugMode) {
              print("$shouldSkipAuth API CLIENT TOKEN :: $token");
            }

            final osType = Platform.isAndroid ? 'Android' : 'iOS';
            final isGalleryApi =
                options.path.contains('/api/v1/mobile') ||
                options.path.startsWith('/home') ||
                options.path.startsWith('/recent') ||
                options.path.startsWith('/collections') ||
                options.path.startsWith('/attributes') ||
                options.path.startsWith('/smruti-of') ||
                options.path.startsWith('/by-attribute') ||
                options.path.startsWith('/locations') ||
                options.path.startsWith('/people') ||
                options.path.startsWith('/faces') ||
                options.path.startsWith('/photos');

            if (ApiEndpoints.mobileApiKey.isNotEmpty) {
              options.headers['X-API-Key'] = ApiEndpoints.mobileApiKey;
            }

            if (!isGalleryApi &&
                !shouldSkipAuth &&
                token != null &&
                token.isNotEmpty) {
              options.headers['Authorization'] = 'Bearer $token';
            }

            if (options.data != null && options.data is! FormData) {
              if (options.data is Map || options.data is List) {
                options.extra['_originalData'] = options.data;
                if (['POST', 'PUT', 'DELETE'].contains(options.method)) {
                  options.data = jsonEncode(options.data);
                }
              }
            }
            if (options.data is FormData) {
              options.headers['Content-Type'] = 'multipart/form-data';
            }

            if (!options.path.contains('http')) {
              options.path = ApiEndpoints.mainDomain + options.path;
            }
            options.headers['X-App-Version'] = "$currentAppVersion-$osType";

            if (kDebugMode) {
              log('📤 REQUEST');
              log('➡️ [${options.method}] ${options.uri}');
              log('🔘 Headers: ${options.headers}');
              log('📝 Data: ${options.data}');
            }

            return handler.next(options);
          },
          onResponse: (response, handler) {
            log(response.toString());
            if (response.statusCode == 200 || response.statusCode == 201) {
              return handler.next(response);
            }
            return handler.reject(
              DioException(
                requestOptions: response.requestOptions,
                response: response,
                type: DioExceptionType.badResponse,
              ),
            );
          },
          onError: (DioException error, handler) async {
            if (kDebugMode) {
              print("🔗 Request URL: ${error.requestOptions.uri}");
              print("🟡 Request Method: ${error.requestOptions.method}");
              print("🟡 Request Method: ${error.requestOptions.method}");
            }

            String url = error.requestOptions.uri.toString();
            String method = error.requestOptions.method;
            int? statusCode = error.response?.statusCode;
            String responseData =
                error.response?.data.toString() ?? 'No response data';

            // Create a structured log
            String log =
                '''
🔻 ERROR LOG 🔻
URL: $url
METHOD: $method
STATUS: $statusCode
DATA: $responseData
''';

            await SecureLogger.write(log);

            if (error.response != null) {
              switch (statusCode) {
                case 400:
                  if (kDebugMode) {
                    print("400 Bad Request Error: $responseData");
                  }
                  break;
                case 401:
                  if (kDebugMode) {
                    print("401 Invalid Token Error: $responseData");
                  }
                  break;
                case 403:
                  if (await _shouldRetry(error)) {
                    return handler.resolve(await _retry(error.requestOptions));
                  }
                  break;
                case 404:
                  if (kDebugMode) {
                    print("404 API Error: $responseData");
                  }
                  break;
                case 440:
                  if (kDebugMode) {
                    print("440 Forced Login Error: $responseData");
                  }
                  break;
                case 500:
                  if (kDebugMode) {
                    print("500 Server Error: Internal Server Error");
                  }
                  break;
                default:
                  if (kDebugMode) {
                    print("Unhandled Error: $statusCode");
                  }
              }
            }

            return handler.next(error);
          },
        ),
      );
    }
  }

  static Future<Response<dynamic>> _retry(RequestOptions requestOptions) async {
    String? newAccessToken = await _refreshToken();
    if (newAccessToken != null) {
      requestOptions.headers['Authorization'] = 'Bearer $newAccessToken';
      return _client!.fetch<dynamic>(requestOptions);
    } else {
      return Response(
        requestOptions: requestOptions,
        statusCode: 440, // Unauthorized
        data: {"error": "Refresh token expired. Please re-login."},
      );
    }
  }

  static Future<String?> _refreshToken() async {
    StorageHelper.setValue(key: StorageKeys.accessToken, value: "");

    String? refreshToken = StorageHelper.getValue(
      key: StorageKeys.refreshToken,
    );
    if (refreshToken == null || refreshToken.isEmpty) {
      _forceLogout();
      return null;
    }

    try {
      final response = await _client!.post(
        ApiEndpoints.refresh,
        options: Options(headers: {'Content-Type': 'application/json'}),
        data: addExtraParameters({
          "refresh_token": StorageHelper.getValue(
            key: StorageKeys.refreshToken,
          ),
        }),
      );

      if (response.statusCode == 200) {
        String newAccessToken = response.data['access'];
        String newRefreshToken = response.data['refresh'];

        StorageHelper.setValue(
          key: StorageKeys.accessToken,
          value: newAccessToken,
        );
        StorageHelper.setValue(
          key: StorageKeys.refreshToken,
          value: newRefreshToken,
        );

        if (kDebugMode) {
          print("✅ Token refreshed successfully!");
        }
        return newAccessToken;
      } else if (response.statusCode == 401) {
        if (kDebugMode) {
          print("🔴 Refresh token expired. Logging out...");
        }
        _forceLogout(); // Call logout function
      }
    } catch (e) {
      if (kDebugMode) {
        print("🔴 Token refresh failed: $e");
      }
      _forceLogout();
    }

    return null;
  }

  static void _forceLogout() {
    if (kDebugMode) {
      print("🔴 Logging out user...");
    }

    StorageHelper.setValue(key: StorageKeys.accessToken, value: "");
    StorageHelper.setValue(key: StorageKeys.refreshToken, value: "");
    get_x.Get.offAll(() => SplashScreen());
  }

  static Future<String?> _getAccessToken() async {
    return StorageHelper.getValue(key: StorageKeys.accessToken);
  }

  static Future<bool> _shouldRetry(DioException error) async {
    if (error.response?.data['detail'].toString() ==
        "Authentication error: Invalid or expired token.") {
      String? refreshToken = StorageHelper.getValue(
        key: StorageKeys.refreshToken,
      );
      if (refreshToken != null && refreshToken.isNotEmpty) {
        if (kDebugMode) {
          print("🔄 Should retry: 403 detected & refresh token is available.");
        }
        return true;
      } else {
        if (kDebugMode) {
          print("🔴 Should NOT retry: No valid refresh token found.");
        }
        return false;
      }
    } else if (error.response?.data['detail'].toString() ==
        "Authentication error: Please install latest app version") {
      EasyLoading.showError(
        error.response!.data['detail']
            .toString()
            .split(":")
            .last
            .trim()
            .toString(),
        duration: Duration(days: 3),
      );
    }
    return false;
  }

  static Future<Response<dynamic>> get(
    String path, {
    Map<String, dynamic>? queryParams,
    Map<String, dynamic>? customHeaders,
  }) async {
    try {
      Response response = await _client!.get(
        path,
        queryParameters: addExtraParameters(queryParams ?? {}),
        options: Options(headers: customHeaders),
      );
      return response;
    } on DioException catch (e) {
      if (kDebugMode) {
        print("Messsssss ${e.error}");
        print("Messsssss ${e.response}");
      }

      throw _handleError(e);
    }
  }

  static Future<Response<dynamic>> post(
    String path, {
    Map<String, dynamic>? data,
    Map<String, dynamic>? queryParams,
    Map<String, dynamic>? customHeaders,
  }) async {
    try {
      Response response = await _client!.post(
        path,
        data: addExtraParameters(data ?? {}),
        queryParameters: queryParams,
      );
      return response;
    } on DioException catch (e) {
      if (kDebugMode) {
        print(e);
      }
      throw _handleError(e);
    }
  }

  static Future<Response<dynamic>> postMedia(
    String path, {
    required FormData data,
  }) async {
    try {
      final processedData = addExtraParametersFromData(data);
      Response response = await _client!.post(
        path,
        data: processedData,
        options: Options(contentType: "multipart/form-data"),
      );
      return response;
    } on DioException catch (e) {
      if (kDebugMode) {
        print(e);
      }
      throw _handleError(e);
    }
  }

  static Future<Response<dynamic>> put(
    String path, {
    Map<String, dynamic>? data,
    Map<String, dynamic>? queryParams,
    Map<String, dynamic>? customHeaders,
  }) async {
    try {
      if (kDebugMode) {
        print(addExtraParameters(data ?? {}));
      }
      Response response = await _client!.put(
        path,
        data: addExtraParameters(data ?? {}),
        queryParameters: queryParams,
      );
      return response;
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  static Future<Response<dynamic>> delete(
    String path, {
    Map<String, dynamic>? data,
    Map<String, dynamic>? queryParams,
    Map<String, dynamic>? customHeaders,
  }) async {
    try {
      Response response = await _client!.delete(
        path,
        data: addExtraParameters(data ?? {}),
        queryParameters: queryParams,
        options: Options(headers: customHeaders),
      );
      return response;
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  static Exception _handleError(DioException error) {
    if (error.response != null) {
      final statusCode = error.response?.statusCode;
      final errorData = error.response?.data;
      final message = errorData is Map
          ? errorData['detail'] ??
                errorData['message'] ??
                'Unknown error message'
          : errorData?.toString() ?? 'Unknown error message';

      final logMessage =
          'Status: $statusCode, Message: $message, Response: $errorData';

      if (kDebugMode) {
        print("Logsssss $logMessage");
      }
      SecureLogger.write(logMessage); // Save to file

      switch (statusCode) {
        case 400:
        case 401:
        case 403:
        case 404:
        case 440:
        case 500:
          if (kDebugMode) {
            print("🛑 Error $statusCode: $message");
          }
          return Exception(message);
        default:
          return Exception("⚠️ Error: $errorData");
      }
    }

    SecureLogger.write("Unknown Dio Error: ${error.message}");
    return Exception("⚠️ Unknown Error: ${error.message}");
  }

  static dynamic addExtraParametersFromData(dynamic data) {
    if (data is FormData) {
      final extraFields = {};
      data.fields.addAll(
        extraFields.entries.map((e) => MapEntry(e.key, e.value.toString())),
      );
      return data;
    } else {
      return data;
    }
  }

  static dynamic addExtraParameters(Map<String, dynamic> data) {
    return {...data};
  }

  static bool handleValidationError(dynamic json) {
    if (json is Map && json.containsKey('message')) {
      final message = json['message'].toString();
      if (message.isNotEmpty) {
        EasyLoading.showError(message);
        return false; // error handled
      }
    }
    return true;
  }
}
